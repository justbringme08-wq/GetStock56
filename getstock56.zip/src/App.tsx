import { useState, useEffect, MouseEvent, FormEvent } from "react";
import { 
  Sparkles, 
  Target, 
  ArrowRight, 
  History, 
  Heart, 
  Copy, 
  Download, 
  Zap, 
  Loader2, 
  Check, 
  Trash2, 
  HelpCircle, 
  Send,
  ExternalLink,
  ChevronDown,
  Briefcase,
  Mail,
  Home,
  MessageSquare,
  Globe,
  TrendingUp,
  Award,
  Settings,
  Sliders,
  X,
  Search,
  Check as Shield
} from "lucide-react";
import { Hook, FavoriteHook, RecentSearch, ToneType, LanguageType } from "./types";

export default function App() {
  // New System & Config States
  const [activeSection, setActiveSection] = useState("home");
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [platform, setPlatform] = useState<string>("TikTok");
  const [ugcStyle, setUgcStyle] = useState<string>("Casual Creator Voice");
  const [prefixModifier, setPrefixModifier] = useState<boolean>(true);
  const [simulationMode, setSimulationMode] = useState<string>("turbo");

  // Filter Query for FAQs & Calculator state
  const [searchQueryFaq, setSearchQueryFaq] = useState("");
  const [calcMonthlySpend, setCalcMonthlySpend] = useState<number>(12500);
  const [calcHookRate, setCalcHookRate] = useState<number>(15);

  // Live Activity Telemetry Alert logs
  const [liveActivities, setLiveActivities] = useState<string[]>([
    "🚀 Juan C. scaled to +45% Hook Rate using Direct Aggressive tone.",
    "🎬 Production team casted 3 new Creators for skincare video briefs.",
    "🔥 Taglish Hook generated for client: '🏋️ Fitness App' campaign.",
    "🛡️ LocalStorage synchronized on port 3000 securely.",
    "💡 Brand Audit requested for meta-ads-growth.myshopify.com."
  ]);

  // AI Form State
  const [productDescription, setProductDescription] = useState("");
  const [language, setLanguage] = useState<LanguageType>("English");
  const [tone, setTone] = useState<ToneType>("Direct & Aggressive");
  const [isLoading, setIsLoading] = useState(false);
  const [loadingText, setLoadingText] = useState("Analyzing angles & generating hooks...");
  const [generatedHooks, setGeneratedHooks] = useState<Hook[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Persistence State
  const [recentSearches, setRecentSearches] = useState<RecentSearch[]>([]);
  const [favorites, setFavorites] = useState<FavoriteHook[]>([]);
  
  // UI States
  const [copiedHookId, setCopiedHookId] = useState<number | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  
  // Contact Form State
  const [contactName, setContactName] = useState("");
  const [contactEmail, setContactEmail] = useState("");
  const [contactWebsite, setContactWebsite] = useState("");
  const [contactMessage, setContactMessage] = useState("");
  const [contactSubmitting, setContactSubmitting] = useState(false);
  const [contactSuccess, setContactSuccess] = useState(false);

  // FAQ Accordion State
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  // Dynamic Suggestion Templates
  const suggestions = [
    { label: "✨ Skincare Serum", desc: "A skincare serum that clears acne breakouts in 7 days without causing skin dryness." },
    { label: "🏋️ Fitness App", desc: "A mobile workout application with 15-minute home routines that gets you ripped." },
    { label: "📚 Reading App", desc: "An audio book summary app that lets you read a non-fiction bestseller in 12 minutes." },
  ];

  // Load localStorage on mount
  useEffect(() => {
    try {
      // 1. Load searches and favorites
      const persistedSearches = localStorage.getItem("g56_recent_searches");
      if (persistedSearches) {
        setRecentSearches(JSON.parse(persistedSearches));
      }
      const persistedFavorites = localStorage.getItem("g56_favorites");
      if (persistedFavorites) {
        setFavorites(JSON.parse(persistedFavorites));
      }

      // 2. Load system settings
      const persistedSettings = localStorage.getItem("g56_agency_settings");
      if (persistedSettings) {
        const parsed = JSON.parse(persistedSettings);
        if (parsed.platform) setPlatform(parsed.platform);
        if (parsed.ugcStyle) setUgcStyle(parsed.ugcStyle);
        if (parsed.prefixModifier !== undefined) setPrefixModifier(parsed.prefixModifier);
        if (parsed.simulationMode) setSimulationMode(parsed.simulationMode);
      }
    } catch (e) {
      console.error("Failed to load local storage state:", e);
    }
  }, []);

  // System settings writer
  const updateSystemSettings = (newPlat: string, newStyle: string, newPref: boolean, newSim: string) => {
    setPlatform(newPlat);
    setUgcStyle(newStyle);
    setPrefixModifier(newPref);
    setSimulationMode(newSim);
    localStorage.setItem("g56_agency_settings", JSON.stringify({
      platform: newPlat,
      ugcStyle: newStyle,
      prefixModifier: newPref,
      simulationMode: newSim
    }));
  };

  // Scroll spy effect to highlight active menu section links dynamically
  useEffect(() => {
    const handleScroll = () => {
      const sections = ["home", "ai-tool", "services", "faq", "contact"];
      const scrollPosition = window.scrollY + 250;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Periodic simulated live conversion telemetry
  useEffect(() => {
    const alerts = [
      "🔥 TikTok UGC casted 3 new beauty creators for high-converting hook tests.",
      "🚀 Juan C. scaled to +72% Hook Rate using Direct Aggressive tone.",
      "💡 Pro Tip: Shorten hooks to 9 words for maximum mobile user retention.",
      "⚡ Advantage+ campaign delivered +18.4% budget efficiency today.",
      "🎬 Audio sound pattern matched with pattern-interrupt overlay.",
      "🇵🇭 Taglish Hook successfully prefilled for Pinoy local brand.",
      "📈 Hook rate raised from 14% to 49.3% in skin-brand live audit.",
      "🛡️ LocalStorage synchronized on port 3000 securely with system."
    ];

    const interval = setInterval(() => {
      setLiveActivities(prev => {
        const next = [...prev];
        next.unshift(alerts[Math.floor(Math.random() * alerts.length)]);
        return next.slice(0, 5); // Keep top 5
      });
    }, 8000);

    return () => clearInterval(interval);
  }, []);

  // Update loading texts sequentially during generation to keep user engaged
  useEffect(() => {
    if (!isLoading) return;
    const phrases = [
      `Analyzing competitive ${platform} hooks...`,
      "Formulating emotional conversion angles...",
      "Crafting attention-grabbing pattern interrupts...",
      `Reviewing target ${platform} audience demographics...`,
      `Adapting copy for "${ugcStyle}" visual blueprint...`,
      "Optimizing visual direction triggers & CTA..."
    ];
    let index = 0;
    const interval = setInterval(() => {
      index = (index + 1) % phrases.length;
      setLoadingText(phrases[index]);
    }, 2000);
    return () => clearInterval(interval);
  }, [isLoading, platform, ugcStyle]);

  // Helper: Save Searches
  const saveSearch = (description: string, searchLang: LanguageType, searchTone: ToneType) => {
    const newSearch: RecentSearch = {
      id: Math.random().toString(36).substring(2, 9),
      productDescription: description,
      language: searchLang,
      tone: searchTone,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };
    const updated = [newSearch, ...recentSearches.filter(s => s.productDescription.toLowerCase() !== description.toLowerCase())].slice(0, 10);
    setRecentSearches(updated);
    localStorage.setItem("g56_recent_searches", JSON.stringify(updated));
  };

  // Helper: Trigger Search Prefill
  const handleLoadRecent = (item: RecentSearch) => {
    setProductDescription(item.productDescription);
    setLanguage(item.language as LanguageType);
    setTone(item.tone as ToneType);
    
    // Smooth scroll back to workspace form if clicked
    document.getElementById("ai-tool")?.scrollIntoView({ behavior: "smooth" });
  };

  // Helper: Delete Specific Search
  const handleDeleteSearch = (id: string, e: MouseEvent) => {
    e.stopPropagation();
    const updated = recentSearches.filter(s => s.id !== id);
    setRecentSearches(updated);
    localStorage.setItem("g56_recent_searches", JSON.stringify(updated));
  };

  // Helper: Clear All Searches
  const handleClearAllSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem("g56_recent_searches");
  };

  // Helper: Favorite/Unfavorite Toggle
  const toggleFavorite = (hook: Hook) => {
    const exists = favorites.find(f => f.hookText === hook.hookText);
    let updated: FavoriteHook[];
    if (exists) {
      updated = favorites.filter(f => f.hookText !== hook.hookText);
    } else {
      const newFav: FavoriteHook = {
        ...hook,
        id: Math.random().toString(36).substring(2, 9),
        timestamp: new Date().toLocaleDateString(),
        productDescription: productDescription || "Custom Product Sample",
        language,
        tone
      };
      updated = [newFav, ...favorites];
    }
    setFavorites(updated);
    localStorage.setItem("g56_favorites", JSON.stringify(updated));
  };

  const isFavorite = (hookText: string) => {
    return favorites.some(f => f.hookText === hookText);
  };

  // Core API: Generate Hooks
  const generateHooks = async () => {
    if (!productDescription.trim()) {
      setErrorMsg("Please introduce your product or service to generate scroll-stoppers.");
      return;
    }

    setIsLoading(true);
    setGeneratedHooks([]);
    setErrorMsg(null);
    setSuccessMsg(null);

    // If deep-analyze is checked, put extra artificial pre-evaluation lag to look professional
    if (simulationMode === "deep-analyze") {
      setLoadingText("Initializing deep conversion parser...");
      await new Promise(resolve => setTimeout(resolve, 1800));
    }

    try {
      const response = await fetch("/api/generate-hooks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productDescription,
          language,
          tone,
          platform,
          ugcStyle,
          prefixModifier
        })
      });

      if (!response.ok) {
        throw new Error("We encountered a fast network throttle. Let's try once more.");
      }

      const data = await response.json();
      if (data && data.hooks) {
        setGeneratedHooks(data.hooks);
        saveSearch(productDescription, language, tone);
        setSuccessMsg("Successfully loaded 5 high-converting performance hooks!");
        
        // Scroll to results cleanly
        setTimeout(() => {
          document.getElementById("hook-results")?.scrollIntoView({ behavior: "smooth" });
        }, 300);
      } else {
        throw new Error("Invalid output received from the generation engine.");
      }
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "An unexpected error occurred. Please test again.");
    } finally {
      setIsLoading(false);
    }
  };

  // Global keyboard shortcut to trigger hook generation via Cmd+Enter / Ctrl+Enter
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "Enter") {
        if (!isLoading && productDescription.trim()) {
          e.preventDefault();
          // Force active element to blur to commit any pending changes (safeguard)
          if (document.activeElement instanceof HTMLElement) {
            document.activeElement.blur();
          }
          generateHooks();
        }
      }
    };

    window.addEventListener("keydown", handleGlobalKeyDown);
    return () => {
      window.removeEventListener("keydown", handleGlobalKeyDown);
    };
  }, [isLoading, productDescription, language, tone, platform, ugcStyle, prefixModifier, simulationMode]);

  // Copy Single Hook
  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedHookId(index);
    setTimeout(() => setCopiedHookId(null), 2000);
  };

  // Copy All Hooks Consolidated
  const handleCopyAll = () => {
    if (generatedHooks.length === 0) return;
    const consolidated = generatedHooks.map((h, i) => {
      return `[HOOK ${i+1}] (${tone} - ${language})\nCopy: "${h.hookText}"\nVisual Action Clip: ${h.visualCue}\nWhy it works: ${h.reason}\n`;
    }).join("\n---\n\n");
    
    navigator.clipboard.writeText(consolidated);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  // Export Hook to a convenient Local .txt File
  const handleExportTxt = () => {
    if (generatedHooks.length === 0) return;
    const documentHeadline = `==================================================\n`;
    const documentTitle = `   GETSTOCK56 - HIGH CONVERTING PERFORMANCE HOOKS\n`;
    const documentMeta = `   Product: ${productDescription}\n   Tone: ${tone} | Language: ${language}\n`;
    const documentDivider = `==================================================\n\n`;
    
    const body = generatedHooks.map((h, i) => {
      return `HOOK ${i+1}:\n--------------------------------------------------\nCopy: "${h.hookText}"\n\nVisual UGC Action Guide:\n👉 ${h.visualCue}\n\nPsychology Behind Conversion Angle:\n💡 ${h.reason}\n\n`;
    }).join("\n");

    const fullContent = `${documentHeadline}${documentTitle}${documentMeta}${documentDivider}${body}Generated with GetStock56 AI - Scale Across All Platforms.`;
    
    const blob = new Blob([fullContent], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `GetStock56_Hooks_${tone.replace(/\s+/g, '_')}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  // Contact Form submit logic (simulated with feedback)
  const handleContactSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactEmail || !contactMessage) {
      alert("Please fill out all mandatory contact fields.");
      return;
    }
    setContactSubmitting(true);
    setTimeout(() => {
      setContactSubmitting(false);
      setContactSuccess(true);
      // Reset form
      setContactName("");
      setContactEmail("");
      setContactWebsite("");
      setContactMessage("");
    }, 1500);
  };

  // FAQ array according to marketing agencies needs
  const faqItems = [
    {
      q: "What makes GetStock56 hooks convert higher than ordinary scripts?",
      a: "Our hooks rely on analytical structure and visual behavior rather than static taglines. Every generated hook contains both copy text (the pattern-interrupter) and a targeted UGC (User Generated Content) action block for the first 3 seconds of video, which forces immediate curiosity and keeps viewers past the critical skip barrier."
    },
    {
      q: "Can I use the Tagalog generator for local Philippine TikTok shops?",
      a: "Yes! Our Tagalog engine does not just translate textbook sentences. It generates organic 'Taglish' and natural colloquial phrasing. This ensures your local dropshipping or local brand ads sound authentic, highly relatable, and perfectly tailored to current Pinoy trends."
    },
    {
      q: "Do you offer full-service media buying options?",
      a: "Absolutely. We represent a bespoke, high-performance universal growth agency. We operate end-to-end UGC casting, creative orchestration, budget structures, and custom funnels for Meta (Facebook/Instagram Ads) and TikTok Ads."
    },
    {
      q: "How does the saved favorites sidebar store my selections?",
      a: "All of your favorited hooks and history are saved securely in your web browser utilizing modern HTML5 LocalStorage. There are no registration screens required; you can revisit, export, and utilize them anytime directly from this browser."
    }
  ];

  return (
    <div className="bento-bg-grid bg-[#f8fafc] text-slate-900 font-sans min-h-screen flex flex-col selection:bg-pink-100 selection:text-pink-900 pb-20 md:pb-0">
      
      {/* Dynamic Header Section matching Bento Layout values */}
      <header className="sticky top-0 z-50 bg-[#f8fafc]/90 backdrop-blur-md border-b border-slate-200/80 px-4 md:px-8 py-4">
        <div className="max-w-6xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-pink-500 rounded-2xl flex items-center justify-center text-white font-extrabold italic tracking-tighter shadow-sm transform hover:-rotate-6 transition-all">
              G56
            </div>
            <a href="#home" className="text-xl md:text-2xl font-black tracking-tighter">
              GET<span className="text-pink-500">STOCK56</span>
            </a>
          </div>

          <nav className="hidden md:flex items-center gap-6 text-[12px] font-black tracking-widest text-slate-600">
            <a 
              href="#services" 
              className={`transition-colors uppercase ${
                activeSection === "services" ? "text-pink-600 font-extrabold" : "hover:text-pink-500 text-slate-500"
              }`}
            >
              Services
            </a>
            <a 
              href="#ai-tool" 
              className={`transition-colors uppercase ${
                activeSection === "ai-tool" ? "text-pink-600 font-extrabold" : "hover:text-pink-500 text-slate-500"
              }`}
            >
              AI Tools
            </a>
            <a 
              href="#faq" 
              className={`transition-colors uppercase ${
                activeSection === "faq" ? "text-pink-600 font-extrabold" : "hover:text-pink-500 text-slate-500"
              }`}
            >
              FAQ
            </a>
            <a 
              href="#contact" 
              className={`transition-colors uppercase ${
                activeSection === "contact" ? "text-pink-600 font-extrabold" : "hover:text-pink-500 text-slate-500"
              }`}
            >
              Contact Agency
            </a>
            
            {/* Real Settings button in Header */}
            <button 
              onClick={() => setSettingsOpen(true)}
              className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-full transition-all flex items-center gap-1 cursor-pointer"
              title="Configure System Parameters"
            >
              <Settings className="w-3.5 h-3.5 text-pink-500 animate-spin-slow" />
              <span className="font-bold text-[9px] tracking-widest">SETTINGS</span>
            </button>

            <a href="#contact" className="bg-black text-white px-6 py-2.5 rounded-full hover:bg-slate-800 transition-all font-bold tracking-normal shadow-sm">
              GET STARTED
            </a>
          </nav>
        </div>
      </header>

      {/* PERSISTENT SYSTEM CONFIGURATION MODAL (Bento Grid Style Alignment) */}
      {settingsOpen && (
        <div id="settings-modal" className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-md p-4 animate-fade-in text-left">
          <div className="bg-white border-2 border-slate-900 rounded-[32px] max-w-lg w-full p-6 md:p-8 shadow-2xl relative transform scale-100 transition-all">
            <button 
              onClick={() => setSettingsOpen(false)}
              className="absolute top-6 right-6 p-2 text-slate-400 hover:text-slate-950 rounded-full hover:bg-slate-100 transition-colors"
              aria-label="Close configuration overlay"
            >
              <X className="w-5 h-5" />
            </button>
            
            <div className="flex items-center gap-3.5 border-b border-slate-100 pb-4 mb-6">
              <div className="w-10 h-10 bg-pink-500 text-white rounded-2xl flex items-center justify-center font-bold">
                <Sliders className="w-5 h-5 text-white" />
              </div>
              <div>
                <h3 className="text-xl font-black text-slate-900 tracking-tight">G56 System Configuration</h3>
                <p className="text-[10px] text-slate-400 font-extrabold uppercase tracking-widest">Setup Ad Targeting Mechanics</p>
              </div>
            </div>

            <div className="space-y-4">
              {/* Option 1: Platform Selection */}
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                  Target Traffic Platform
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {["TikTok", "Instagram Reels", "YouTube Shorts", "Meta Ads"].map((platName) => (
                    <button
                      key={platName}
                      type="button"
                      onClick={() => setPlatform(platName)}
                      className={`py-2.5 px-2 rounded-xl font-bold text-xs text-center border transition-all ${
                        platform === platName 
                        ? "bg-slate-900 text-white border-slate-900" 
                        : "bg-slate-50 text-slate-600 hover:bg-slate-100 border-transparent"
                      }`}
                    >
                      {platName.replace(" Ads", "")}
                    </button>
                  ))}
                </div>
              </div>

              {/* Option 2: UGC Vibe Style */}
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                  UGC Acting Behavior Vibe Style
                </label>
                <select 
                  value={ugcStyle}
                  onChange={(e) => setUgcStyle(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-pink-500/20 text-xs text-slate-800 font-bold outline-none"
                >
                  <option value="Casual Creator Voice">Casual Creator Voice (Simple, Raw Phone Recording)</option>
                  <option value="Cinematic Narrative">Cinematic Narrative (Clean contrast, high definition story)</option>
                  <option value="Lo-Fi Street Vlog">Lo-Fi Street Vlog (Handheld shaking camera, high authenticity)</option>
                  <option value="ASMR / Aesthetic">ASMR / Aesthetic (Satisyfing closeups, premium textures)</option>
                </select>
              </div>

              {/* Option 3: Prefix Modifer checkbox toggle */}
              <div className="p-3.5 bg-pink-50/50 rounded-2xl border border-pink-100/60 flex items-start gap-3">
                <input 
                  id="opt-prefix"
                  type="checkbox"
                  checked={prefixModifier}
                  onChange={(e) => setPrefixModifier(e.target.checked)}
                  className="mt-1 accent-pink-500 h-4 w-4"
                />
                <div className="text-left">
                  <label htmlFor="opt-prefix" className="text-xs font-black text-slate-800 block cursor-pointer select-none">
                    Inject Shocking Headscreen Prefixes
                  </label>
                  <span className="text-[10px] text-slate-500 font-medium leading-relaxed block mt-0.5">
                    Prepend high pattern-interrupt phrases to all generated copy lines (e.g. "⚠️ STOP SCROLLING!", "⚡ UNPOPULAR OPINION:", "⚠️ PRO TIP:") automatically.
                  </span>
                </div>
              </div>

              {/* Option 4: AI Model Evaluation Depth */}
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                  AI Multi-Agent Evaluation Depth
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setSimulationMode("turbo")}
                    className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                      simulationMode === "turbo"
                      ? "bg-pink-100 text-pink-700 border border-pink-200"
                      : "bg-slate-50 text-slate-500 hover:text-slate-900 border border-transparent"
                    }`}
                  >
                    🚀 Turbo Delivery (Instant API)
                  </button>
                  <button
                    type="button"
                    onClick={() => setSimulationMode("deep-analyze")}
                    className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all ${
                      simulationMode === "deep-analyze"
                      ? "bg-pink-100 text-pink-700 border border-pink-200"
                      : "bg-slate-50 text-slate-500 hover:text-slate-900 border border-transparent"
                    }`}
                  >
                    🧠 Deep Creative Parser (+1.8s Analytical Mode)
                  </button>
                </div>
              </div>
            </div>

            <div className="mt-8 flex gap-3">
              <button
                type="button"
                onClick={() => {
                  updateSystemSettings(platform, ugcStyle, prefixModifier, simulationMode);
                  setSettingsOpen(false);
                }}
                className="flex-1 bg-black text-white hover:bg-slate-800 py-3 rounded-xl font-black text-xs tracking-wider transition-all"
              >
                APPLY CONFIGURATION
              </button>
              <button
                type="button"
                onClick={() => {
                  setPlatform("TikTok");
                  setUgcStyle("Casual Creator Voice");
                  setPrefixModifier(true);
                  setSimulationMode("turbo");
                }}
                className="px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 py-3 rounded-xl font-bold text-xs transition-all"
                title="Restore default agency values"
              >
                RESET
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main Container */}
      <main id="home" className="max-w-6xl mx-auto px-4 md:px-6 py-6 flex-grow w-full">
        
        {/* BENTO GRID (Responsive Grid Framework) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 auto-rows-min mb-16">
          
          {/* Bento Block 1: Massive Interactive Hero Section (col-span-12 or 8) */}
          <div className="col-span-1  lg:col-span-8 bg-white border border-slate-200/90 rounded-[32px] p-6 md:p-10 flex flex-col justify-center relative overflow-hidden shadow-sm hover:shadow-md transition-shadow">
            <div className="absolute -top-12 -right-12 w-64 h-64 bg-pink-500/10 rounded-full blur-3xl pointer-events-none"></div>
            <div className="absolute -bottom-12 -left-12 w-48 h-48 bg-rose-500/5 rounded-full blur-2xl pointer-events-none"></div>

            <span className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-pink-50 border border-pink-100 text-pink-600 rounded-full text-[11px] font-black tracking-widest uppercase mb-6 self-start">
              <Zap className="w-3.5 h-3.5 fill-pink-500" /> Universal Growth Collective
            </span>

            <h1 className="text-4xl sm:text-5xl md:text-7xl font-sans font-black leading-[0.95] tracking-tight mb-6">
              SCALE ACROSS<br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-rose-400">
                ALL PLATFORMS
              </span>
            </h1>
            
            <p className="text-md md:text-lg text-slate-500 max-w-lg font-medium leading-relaxed mb-8">
              High-converting ad strategies for TikTok, Meta, and beyond. We unlock raw multi-digit ROAS scalability for retail and high-growth consumer brands.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="https://getstartedtiktok.partnerlinks.io/l05gptx6mnto"
                target="_blank"
                rel="noopener noreferrer"
                className="px-8 py-4 bg-black text-white rounded-full font-bold flex items-center justify-center gap-2 transform hover:-translate-y-0.5 transition-all shadow-md shadow-pink-500/5 hover:bg-slate-800 cursor-pointer"
              >
                START SCALING
                <ArrowRight className="w-4 h-4 text-pink-500" />
              </a>
              <a 
                href="#services"
                className="px-8 py-4 border-2 border-slate-100 hover:border-slate-200 rounded-full text-slate-700 font-bold text-center transition-colors"
              >
                SERVICES HUB
              </a>
            </div>
          </div>

          {/* Bento Block 2: Free AI Hook Generator Widget (Interactive App Core, col-span-4) */}
          <div id="ai-tool" className="col-span-1 lg:col-span-4 lg:row-span-2 bg-pink-50/60 border border-pink-100/90 rounded-[32px] p-6 md:p-8 flex flex-col shadow-sm scroll-mt-24">
            <div className="flex justify-between items-center mb-4">
              <div className="bg-pink-500 text-white text-[9px] font-black px-3 py-1 rounded-full uppercase tracking-widest">
                PROPRIETARY AI
              </div>
              <Sparkles className="w-5 h-5 text-pink-500 animate-pulse" />
            </div>

            <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight mb-2">
              Hook Generator
            </h2>
            <p className="text-sm text-slate-600 mb-3 leading-relaxed">
              Stumped on ad creatives? Input your details to generate pattern-interrupt TikTok & Reels script triggers immediately.
            </p>

            {/* Active Connected Settings Label */}
            <div className="flex items-center gap-1.5 mb-5 bg-white/70 p-2.5 rounded-2xl text-[10px] text-slate-500 font-bold border border-pink-100/60 shadow-inner">
              <span className="shrink-0 flex items-center gap-1">🎯 <strong>{platform}</strong></span>
              <span>·</span>
              <span className="truncate">🎬 <em>{ugcStyle}</em></span>
              {prefixModifier && (
                <>
                  <span>·</span>
                  <span className="text-pink-600 shrink-0">⚠️ Shock-Prefix Active</span>
                </>
              )}
              <button 
                type="button" 
                onClick={() => setSettingsOpen(true)}
                className="text-pink-500 hover:text-pink-700 underline text-[9px] font-black uppercase tracking-wider ml-auto cursor-pointer"
              >
                Change
              </button>
            </div>
            
            {/* Form workspace */}
            <div className="space-y-4 flex-grow flex flex-col">
              
              {/* Suggestion tags */}
              <div>
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider mb-2 block">
                  Click a Sample to Quick Fill:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {suggestions.map((s, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => setProductDescription(s.desc)}
                      className="text-[11px] bg-white border border-pink-200 text-slate-700 px-2.5 py-1 rounded-full font-semibold hover:border-pink-400 hover:bg-pink-50 transition-all cursor-pointer"
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Product input */}
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                  Describe Product / Service
                </label>
                <textarea 
                  rows={3}
                  value={productDescription}
                  onChange={(e) => setProductDescription(e.target.value)}
                  placeholder="e.g. A lightweight skin serum that clears acne in 7 days without drying skin..." 
                  className="w-full bg-white border border-pink-100 rounded-2xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-pink-500/20 text-slate-800 font-medium placeholder:text-slate-400 leading-relaxed resize-none"
                />
                <div className="flex justify-between items-center px-1 text-[9px] text-slate-400 font-bold">
                  <span>Describe specific pain points or metrics.</span>
                  <span className="hidden sm:inline-flex items-center gap-1">
                    Press <kbd className="font-mono bg-slate-100 border border-slate-200 px-1 rounded text-slate-600 scale-95 select-none">⌘ + Enter</kbd> (or Ctrl+Enter) to generate
                  </span>
                </div>
              </div>

              {/* Language Selection Toggle */}
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                  Language Output
                </label>
                <div className="grid grid-cols-2 gap-2 bg-white/70 border border-pink-100 p-1 rounded-2xl">
                  <button 
                    type="button" 
                    onClick={() => setLanguage("Tagalog")}
                    className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      language === "Tagalog" 
                        ? "bg-white text-pink-600 shadow-sm border border-pink-100" 
                        : "text-slate-500 hover:text-slate-900"
                    }`}
                  >
                    <span className="text-sm">🇵🇭</span> Tagalog
                  </button>
                  <button 
                    type="button" 
                    onClick={() => setLanguage("English")}
                    className={`py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                      language === "English" 
                        ? "bg-white text-pink-600 shadow-sm border border-pink-100" 
                        : "text-slate-500 hover:text-slate-900"
                    }`}
                  >
                    <span className="text-xs">🇺🇸</span> English
                  </button>
                </div>
              </div>

              {/* Tone Selection Drops */}
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                  Psychology Tone Angle
                </label>
                <select 
                  value={tone}
                  onChange={(e) => setTone(e.target.value as ToneType)}
                  className="w-full p-3.5 bg-white border border-pink-100 rounded-2xl focus:outline-none focus:ring-2 focus:ring-pink-500/25 text-slate-800 font-bold text-xs bg-[url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23ec4899%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E')] bg-[length:0.65rem_auto] bg-[right_1rem_center] bg-no-repeat appearance-none"
                >
                  <option value="Direct & Aggressive">Direct & Aggressive (Hard Pain Point)</option>
                  <option value="Informative & Educational (Curiosity Hack)">Informative & Educational</option>
                  <option value="Humorous & Relatable (Relatable UGC)">Humorous & Relatable</option>
                  <option value="Curiosity & Mystery (Deep Secrets)">Curiosity & Mystery</option>
                  <option value="Urgent & FOMO (Strict Deadline)">Urgent & FOMO</option>
                </select>
              </div>

              {/* Error block */}
              {errorMsg && (
                <div className="bg-red-50 text-red-600 p-3 rounded-2xl text-xs font-semibold border border-red-100">
                  {errorMsg}
                </div>
              )}

              {/* Interactive trigger */}
              <button 
                type="button"
                onClick={generateHooks}
                disabled={isLoading}
                className="w-full bg-black text-white hover:bg-slate-800 disabled:bg-slate-400 p-4 rounded-2xl font-black tracking-wider text-xs shadow-lg shadow-pink-500/5 mt-auto flex items-center justify-center gap-2.5 transform active:scale-98 transition-all cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 text-pink-500 animate-spin" />
                    GENERATING...
                  </>
                ) : (
                  <>
                    <span className="flex items-center gap-1.5 justify-center">
                      GENERATE AD HOOKS
                      <kbd className="hidden sm:inline-flex items-center bg-slate-800 text-[9px] px-1.5 py-0.5 rounded text-slate-400 border border-slate-700 font-mono font-medium scale-90 select-none">⌘↵</kbd>
                    </span>
                    <Sparkles className="w-4 h-4 text-pink-500" />
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Bento Block 3: Metrics UGC Show (col-span-4) */}
          <div className="col-span-1 md:col-span-6 lg:col-span-4 bg-white border border-slate-200/95 rounded-[32px] p-6 flex flex-col justify-between group hover:border-pink-200 transition-all duration-300">
            <div className="flex justify-between items-start mb-8">
              <div className="w-12 h-12 bg-pink-50 text-pink-500 rounded-2xl flex items-center justify-center transform group-hover:scale-115 transition-transform">
                <TrendingUp className="w-6 h-6" />
              </div>
              <span className="text-xs font-black text-green-500 uppercase tracking-widest bg-green-50 px-2.5 py-1 rounded-full border border-green-100">
                +42% Conversion Spike
              </span>
            </div>
            <div>
              <h3 className="text-2xl font-black text-slate-900 tracking-tight leading-none mb-2">
                TIKTOK & REELS
              </h3>
              <p className="text-xs text-slate-400 font-extrabold uppercase tracking-widest">
                UGC Strategy & Media Orchestration
              </p>
            </div>
          </div>

          {/* Bento Block 4: Metrics Meta Ads ROAS (col-span-4) */}
          <div className="col-span-1 md:col-span-6 lg:col-span-4 bg-white border border-slate-200/95 rounded-[32px] p-6 flex flex-col justify-between group hover:border-blue-200 transition-all duration-300">
            <div className="flex justify-between items-start mb-8">
              <div className="w-12 h-12 bg-blue-50 text-blue-500 rounded-2xl flex items-center justify-center transform group-hover:scale-115 transition-transform">
                <Award className="w-6 h-6" />
              </div>
              <span className="text-xs font-black text-blue-600 uppercase tracking-widest bg-blue-50 px-2.5 py-1 rounded-full border border-blue-100">
                Top 1% Global Agency
              </span>
            </div>
            <div>
              <h3 className="text-2xl font-black text-slate-900 tracking-tight leading-none mb-2">
                META ADS HUB
              </h3>
              <p className="text-xs text-slate-400 font-extrabold uppercase tracking-widest">
                ROI Focused Enterprise Optimization
              </p>
            </div>
          </div>

          {/* Bento Block 5: LIVE SYSTEM TELEMETRY AUDIT RADAR (Interactive, col-span-5) */}
          <div className="col-span-1 lg:col-span-5 bg-slate-950 text-slate-200 rounded-[32px] p-6 md:p-8 flex flex-col justify-between shadow-lg relative overflow-hidden group border border-slate-800">
            <div className="absolute top-0 right-0 w-24 h-24 bg-pink-500/10 rounded-bl-full pointer-events-none"></div>
            
            <div>
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 bg-green-500 rounded-full animate-ping"></span>
                  <span className="text-[10px] font-black text-slate-400 tracking-widest uppercase">G56 Active Radar</span>
                </div>
                <span className="text-[10px] font-mono text-pink-500">Live Telemetry</span>
              </div>
              
              <h3 className="text-xl md:text-2xl font-black text-white tracking-tight mb-2">
                Conversion System Feed
              </h3>
              <p className="text-xs text-slate-400 mb-4 leading-relaxed">
                Real-time operational alerts from our client ad-accounts, local browser sandbox hooks, and creative briefs.
              </p>

              {/* Scrolling ticker stack */}
              <div className="space-y-2 bg-black/40 p-3.5 rounded-2xl border border-slate-800/80 font-mono text-[10px] max-h-[165px] overflow-y-auto custom-scrollbar text-left text-slate-300">
                {liveActivities.map((act, i) => (
                  <div key={i} className="flex items-start gap-1.5 py-1 border-b border-slate-900/50 last:border-0 hover:text-white transition-colors">
                    <span className="text-pink-500 shrink-0 select-none">&gt;</span>
                    <span className="leading-normal">{act}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-2 mt-4 pt-3 border-t border-slate-900">
              <button
                type="button"
                onClick={() => {
                  setLiveActivities(prev => [
                    `⚡ Manual diagnostics ping received: Latency <12ms from Port 3000.`,
                    ...prev
                  ].slice(0, 5));
                }}
                className="flex-grow text-[9px] bg-slate-900 hover:bg-slate-800 text-slate-300 px-3 py-2 rounded-xl font-bold tracking-widest uppercase transition-colors"
              >
                Diagnostic Ping
              </button>
              <button
                type="button"
                onClick={() => {
                  try {
                    localStorage.removeItem("g56_recent_searches");
                    localStorage.removeItem("g56_favorites");
                    setRecentSearches([]);
                    setFavorites([]);
                    setLiveActivities(prev => [
                      "🚨 Cache database cleared: All localStorage keys flushed.",
                      ...prev
                    ].slice(0, 5));
                  } catch (e) {
                    console.error(e);
                  }
                }}
                className="text-[9px] bg-red-950/40 hover:bg-red-950/80 text-red-400 px-3 py-2 rounded-xl font-bold tracking-widest uppercase transition-colors"
                title="Clear all local data structures"
              >
                Clear Sandbox
              </button>
            </div>
          </div>

          {/* Bento Block 6: DYNAMIC ROI AD-SPEND CONVERSION CALCULATOR (Interactive, col-span-7) */}
          {(() => {
            const chartPadding = { top: 15, right: 15, bottom: 20, left: 30 };
            const chartHeight = 150;
            const graphHeight = 115;
            
            const heightScale = (pct: number) => {
              return chartPadding.top + graphHeight * (1 - pct / 100);
            };

            return (
              <div className="col-span-1 lg:col-span-7 bg-white border border-slate-200/90 rounded-[32px] p-6 md:p-8 flex flex-col justify-between shadow-sm hover:border-pink-200/80 transition-all duration-300 text-left">
                <div>
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-[10px] font-black text-pink-500 uppercase tracking-widest bg-pink-50 px-2.5 py-1 rounded-full border border-pink-100/40 font-mono">
                      Ad Waste Estimator
                    </span>
                    <span className="text-[10px] text-slate-400 font-bold uppercase">ROI Modeller</span>
                  </div>

                  <h3 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight leading-none mb-1">
                    Ad Spend Salvage Calculator
                  </h3>
                  <p className="text-xs text-slate-500 mb-6 leading-relaxed">
                    If visual hooks fail inside the first 3 seconds, that scroll budget is instantly wasted. Map out your optimization output below.
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                    {/* Left controls & outcomes: col-span-7 */}
                    <div className="md:col-span-7 flex flex-col gap-4 justify-between">
                      <div className="space-y-4">
                        <div className="space-y-1">
                          <div className="flex justify-between text-xs font-bold text-slate-700">
                            <span>Monthly Ad Budget</span>
                            <span className="text-pink-600 font-extrabold">${calcMonthlySpend.toLocaleString()}</span>
                          </div>
                          <input 
                            type="range"
                            min="2000"
                            max="100000"
                            step="2000"
                            value={calcMonthlySpend}
                            onChange={(e) => setCalcMonthlySpend(Number(e.target.value))}
                            className="w-full accent-pink-500 h-1.5 bg-slate-100 rounded-lg cursor-pointer"
                          />
                          <div className="flex gap-1">
                            {[10000, 25000, 50000].map((val) => (
                              <button
                                key={val}
                                type="button"
                                onClick={() => setCalcMonthlySpend(val)}
                                className="text-[9px] font-black text-slate-400 hover:text-slate-900 bg-slate-50 px-2 py-0.5 rounded border border-slate-100 cursor-pointer"
                              >
                                ${val/1000}k
                              </button>
                            ))}
                          </div>
                        </div>

                        <div className="space-y-1">
                          <div className="flex justify-between text-xs font-bold text-slate-700">
                            <span>Existing Hook Rate (3s Retention)</span>
                            <span className="text-blue-600 font-extrabold">{calcHookRate}%</span>
                          </div>
                          <input 
                            type="range"
                            min="5"
                            max="40"
                            step="1"
                            value={calcHookRate}
                            onChange={(e) => setCalcHookRate(Number(e.target.value))}
                            className="w-full accent-blue-500 h-1.5 bg-slate-100 rounded-lg cursor-pointer"
                          />
                          <p className="text-[9px] text-slate-400 font-semibold leading-normal">
                            Percentage of scrollers who watch past 3 seconds. Average is around 15%.
                          </p>
                        </div>
                      </div>

                      {/* Outcomes Panel */}
                      <div className="bg-[#f8fafc] border border-slate-100/80 p-4 rounded-2xl flex flex-col gap-3">
                        <div>
                          <span className="text-[9px] text-slate-400 font-black uppercase tracking-wider block">Currently Wasted Spend (Skips)</span>
                          <span className="text-lg md:text-xl font-black text-slate-900 leading-none">
                            ${Math.round(calcMonthlySpend * (1 - calcHookRate / 100)).toLocaleString()} /mo
                          </span>
                          <div className="w-full bg-slate-200 h-1 rounded-full overflow-hidden mt-1.5">
                            <div className="bg-red-500 h-full rounded-full transition-all duration-300" style={{ width: `${100 - calcHookRate}%` }}></div>
                          </div>
                        </div>

                        <div className="pt-2 border-t border-slate-200/60">
                          <span className="text-[9px] text-pink-500 font-black uppercase tracking-wider block">G56 Reclaimed Operating Capital</span>
                          <span className="text-xl md:text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-rose-500 leading-none">
                            +${Math.round(calcMonthlySpend * (0.45 - calcHookRate / 100) > 0 ? calcMonthlySpend * (0.45 - calcHookRate / 100) : 0).toLocaleString()} /mo
                          </span>
                          <p className="text-[10px] text-slate-500 font-semibold leading-normal mt-1">
                            Estimated value reclaimed by raising retention hooks to 45%.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Right Interactive Chart: col-span-5 */}
                    <div className="md:col-span-5 bg-slate-50 border border-slate-100 p-4 rounded-2xl flex flex-col justify-between">
                      <div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">3s Retention Curve</span>
                          <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-100 animate-pulse">
                            +{Math.round((45 - calcHookRate) / (calcHookRate || 1) * 100)}% Lift
                          </span>
                        </div>
                        
                        {/* SVG Canvas */}
                        <div className="relative w-full h-[140px] bg-white rounded-xl border border-slate-100 shadow-inner p-1 overflow-hidden">
                          <svg viewBox="0 0 300 150" className="w-full h-full overflow-visible">
                            <defs>
                              <linearGradient id="baselineGrad" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.18" />
                                <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.0" />
                              </linearGradient>
                              <linearGradient id="optimizedGrad" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="#ec4899" stopOpacity="0.18" />
                                <stop offset="100%" stopColor="#ec4899" stopOpacity="0.0" />
                              </linearGradient>
                            </defs>

                            {/* Grid Lines */}
                            <line x1="25" y1="15" x2="285" y2="15" stroke="#e2e8f0" strokeDasharray="3,3" strokeWidth="1" />
                            <line x1="25" y1="72" x2="285" y2="72" stroke="#e2e8f0" strokeDasharray="3,3" strokeWidth="1" />
                            <line x1="25" y1="130" x2="285" y2="130" stroke="#cbd5e1" strokeWidth="1" />
                            
                            {/* Vertical timeline markings */}
                            <line x1="111.6" y1="15" x2="111.6" y2="130" stroke="#f1f5f9" strokeWidth="1" />
                            <line x1="198.3" y1="15" x2="198.3" y2="130" stroke="#f1f5f9" strokeWidth="1" />
                            <line x1="285" y1="15" x2="285" y2="130" stroke="#cbd5e1" strokeDasharray="2,2" strokeWidth="1" />

                            {/* Baseline Area Under Curve */}
                            <path 
                              d={`M 25 ${heightScale(100)} L 111.6 ${heightScale(100 - (100 - calcHookRate) * 0.5)} L 198.3 ${heightScale(100 - (100 - calcHookRate) * 0.82)} L 285 ${heightScale(calcHookRate)} L 285 130 L 25 130 Z`}
                              fill="url(#baselineGrad)"
                              className="transition-all duration-300"
                            />
                            
                            {/* G56 Optimized Area Under Curve */}
                            <path 
                              d={`M 25 ${heightScale(100)} L 111.6 ${heightScale(88)} L 198.3 ${heightScale(68)} L 285 ${heightScale(45)} L 285 130 L 25 130 Z`}
                              fill="url(#optimizedGrad)"
                            />

                            {/* Baseline Line */}
                            <path 
                              d={`M 25 ${heightScale(100)} L 111.6 ${heightScale(100 - (100 - calcHookRate) * 0.5)} L 198.3 ${heightScale(100 - (100 - calcHookRate) * 0.82)} L 285 ${heightScale(calcHookRate)}`}
                              fill="none" 
                              stroke="#3b82f6" 
                              strokeWidth="2.5" 
                              strokeLinecap="round" 
                              strokeLinejoin="round"
                              className="transition-all duration-300"
                            />

                            {/* G56 Optimized Line */}
                            <path 
                              d={`M 25 ${heightScale(100)} L 111.6 ${heightScale(88)} L 198.3 ${heightScale(68)} L 285 ${heightScale(45)}`}
                              fill="none" 
                              stroke="#ec4899" 
                              strokeWidth="2.5" 
                              strokeLinecap="round" 
                              strokeLinejoin="round"
                            />

                            {/* Labels & Coordinates */}
                            <text x="30" y="23" fill="#94a3b8" fontSize="8" fontWeight="bold">100%</text>
                            <text x="30" y="78" fill="#94a3b8" fontSize="8" fontWeight="bold">50%</text>
                            <text x="30" y="125" fill="#94a3b8" fontSize="8" fontWeight="bold">0%</text>

                            {/* Timeline markers */}
                            <text x="25" y="143" fill="#cbd5e1" fontSize="7" fontWeight="bold">0s</text>
                            <text x="111.6" y="143" fill="#cbd5e1" fontSize="7" fontWeight="bold" textAnchor="middle">1s</text>
                            <text x="198.3" y="143" fill="#cbd5e1" fontSize="7" fontWeight="bold" textAnchor="middle">2s</text>
                            <text x="285" y="143" fill="#cbd5e1" fontSize="7" fontWeight="bold" textAnchor="end">3s (Hook)</text>

                            {/* Interactive Markers inside graph */}
                            {/* Baseline Terminal Dot */}
                            <circle 
                              cx="285" 
                              cy={heightScale(calcHookRate)} 
                              r="3.5" 
                              fill="#3b82f6" 
                              stroke="#ffffff" 
                              strokeWidth="1.5"
                              className="transition-all duration-300 shadow"
                            />
                            
                            {/* Optimized Terminal Dot */}
                            <circle 
                              cx="285" 
                              cy={heightScale(45)} 
                              r="4" 
                              fill="#ec4899" 
                              stroke="#ffffff" 
                              strokeWidth="1.5"
                              className="shadow"
                            />
                          </svg>
                        </div>

                        {/* Funnel Graph Legend details */}
                        <div className="flex gap-4 items-center mt-3 justify-center text-[10px] font-bold">
                          <span className="flex items-center gap-1 text-slate-500">
                            <span className="w-2.5 h-1 bg-blue-500 rounded-full inline-block"></span>
                            Baseline ({calcHookRate}%)
                          </span>
                          <span className="flex items-center gap-1 text-pink-600">
                            <span className="w-2.5 h-1 bg-pink-500 rounded-full inline-block animate-pulse"></span>
                            G56 Optim. (45%)
                          </span>
                        </div>
                      </div>

                      <p className="text-[9px] text-slate-400 font-medium leading-normal border-t border-slate-100 pt-2.5 mt-2.5 text-center">
                        Higher retention in the first 3 seconds directly stops ad skips and lowers overall CPA.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })()}

        </div>

        {/* LOADING SHIM */}
        {isLoading && (
          <div className="bg-white border border-slate-200 rounded-[32px] p-8 text-center my-6 shadow-sm">
            <div className="flex flex-col items-center justify-center py-10 max-w-md mx-auto">
              <Loader2 className="w-10 h-10 text-pink-500 animate-spin mb-4" />
              <h4 className="font-bold text-slate-900 text-lg mb-2">Creative AI Structuring</h4>
              <p className="text-pink-600 font-semibold animate-pulse text-sm min-h-[24px]">
                {loadingText}
              </p>
              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden mt-6">
                <div className="bg-pink-500 h-full animate-[loading-bar_15s_infinite_linear] rounded-full" style={{ width: '45%' }}></div>
              </div>
            </div>
          </div>
        )}

        {/* AI GENERATED HOOKS COMPONENT (Visible after generation) */}
        {generatedHooks.length > 0 && (
          <div id="hook-results" className="bg-white border-2 border-pink-100 rounded-[32px] p-6 md:p-8 mb-12 shadow-sm animate-fade-in-up">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-100 pb-5 mb-6">
              <div>
                <span className="text-[10px] font-black text-pink-500 uppercase tracking-widest bg-pink-50 px-2.5 py-1 rounded-full">
                  AI Creative Suite
                </span>
                <h3 className="font-extrabold text-slate-900 text-2xl tracking-tight mt-2">
                  Generated Screenplay Hooks
                </h3>
              </div>
              
              <div className="flex flex-wrap gap-2 w-full sm:w-auto">
                <button 
                  onClick={handleCopyAll}
                  className="flex-1 sm:flex-initial text-xs bg-slate-900 hover:bg-black text-white px-4 py-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copiedAll ? (
                    <>
                      <Check className="w-4 h-4 text-green-400" />
                      COPIED ALL!
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-pink-400" />
                      COPY ALL HOOKS
                    </>
                  )}
                </button>
                <button 
                  onClick={handleExportTxt}
                  className="flex-1 sm:flex-initial text-xs bg-white hover:bg-slate-50 text-slate-800 border-2 border-slate-100 px-4 py-2.5 rounded-xl font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Download className="w-4 h-4 text-pink-500" />
                  EXPORT .TXT REPORT
                </button>
              </div>
            </div>

            {/* Generated hook cells */}
            <div className="space-y-6">
              {generatedHooks.map((g, index) => {
                const fav = isFavorite(g.hookText);
                return (
                  <div 
                    key={index} 
                    className="group border border-slate-200/80 rounded-2xl p-5 md:p-6 bg-slate-50/55 hover:bg-white hover:border-pink-200 transition-all relative"
                  >
                    <div className="flex justify-between items-start gap-3 mb-2">
                      <span className="text-xs font-black text-slate-400 uppercase tracking-widest">
                        Angle #{index+1} ({tone})
                      </span>
                      <div className="flex gap-1.5">
                        <button
                          onClick={() => toggleFavorite(g)}
                          className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                            fav 
                              ? "bg-pink-50 border-pink-200 text-pink-600" 
                              : "bg-white border-slate-200 text-slate-400 hover:text-pink-600 hover:border-pink-200"
                          }`}
                          title={fav ? "Remove from Bookmarked Favorites" : "Bookmark this Hook"}
                        >
                          <Heart className={`w-4 h-4 ${fav ? "fill-pink-500 text-pink-500" : ""}`} />
                        </button>
                        <button
                          onClick={() => copyToClipboard(g.hookText, index)}
                          className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                            copiedHookId === index 
                              ? "bg-green-50 border-green-200 text-green-600" 
                              : "bg-white border-slate-200 text-slate-400 hover:text-pink-600 hover:border-pink-200"
                          }`}
                          title="Copy text script text"
                        >
                          {copiedHookId === index ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Copy Subhead block */}
                    <div className="border-l-4 border-pink-500 pl-4 py-1 mb-4">
                      <p className="text-lg md:text-xl font-black text-slate-900 tracking-tight leading-snug">
                        "{g.hookText}"
                      </p>
                    </div>

                    {/* UGC guide and Rationale metadata */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 bg-white/80 p-4 rounded-xl border border-slate-200/60">
                      <div>
                        <span className="text-[10px] font-black text-pink-500 uppercase tracking-widest block mb-1">
                          🎬 UGC Production Guide (0-3s Visuals):
                        </span>
                        <p className="text-xs text-slate-600 font-medium leading-relaxed">
                          {g.visualCue}
                        </p>
                      </div>
                      <div>
                        <span className="text-[10px] font-black text-[#0668E1] uppercase tracking-widest block mb-1">
                          💡 Conversion Psychology Insight:
                        </span>
                        <p className="text-xs text-slate-600 font-medium leading-relaxed">
                          {g.reason}
                        </p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* SIDE-BY-SIDE ANALYST ROW (Recent searches & persistent favorited hooks) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-16">
          
          {/* Recent Queries sidebar block */}
          <div className="bg-white border border-slate-200 rounded-[32px] p-6 md:p-8 flex flex-col justify-between shadow-sm">
            <div>
              <div className="flex justify-between items-center border-b border-slate-100 pb-4 mb-4">
                <h3 className="font-extrabold text-lg text-slate-900 flex items-center gap-2">
                  <History className="w-5 h-5 text-pink-500" />
                  Recent Generator Runs
                </h3>
                {recentSearches.length > 0 && (
                  <button 
                    onClick={handleClearAllSearches}
                    className="text-[11px] text-slate-400 hover:text-red-500 font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" /> Clear All
                  </button>
                )}
              </div>

              {recentSearches.length === 0 ? (
                <div className="text-center text-sm text-slate-400 py-10 italic">
                  Launch the generator above to save research items locally.
                </div>
              ) : (
                <div className="space-y-2 max-h-[280px] overflow-y-auto pr-2 custom-scrollbar">
                  {recentSearches.map((item) => (
                    <div 
                      key={item.id}
                      onClick={() => handleLoadRecent(item)}
                      className="group p-3 border border-slate-100 hover:border-pink-200 hover:bg-pink-50/20 rounded-xl flex items-center justify-between gap-3 transition-colors cursor-pointer text-left"
                    >
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-bold text-slate-800 truncate">
                          {item.productDescription}
                        </p>
                        <p className="text-[10px] text-slate-400 font-semibold mt-0.5">
                          {item.tone} · {item.language} · {item.timestamp}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] bg-slate-100 group-hover:bg-pink-100 text-slate-600 group-hover:text-pink-600 px-2 py-0.5 rounded font-black">
                          LOAD
                        </span>
                        <button 
                          onClick={(e) => handleDeleteSearch(item.id, e)}
                          className="text-slate-300 hover:text-red-500 p-1"
                          title="Delete History Item"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 text-[11px] text-slate-400 font-semibold">
              Tip: Click any history listing above to automatically prefill the generator form.
            </div>
          </div>

          {/* Bookmarked Favorites sidebar block */}
          <div className="bg-white border border-slate-200 rounded-[32px] p-6 md:p-8 flex flex-col justify-between shadow-sm">
            <div>
              <div className="flex justify-between items-center border-b border-slate-100 pb-4 mb-4">
                <h3 className="font-extrabold text-lg text-slate-900 flex items-center gap-2">
                  <Heart className="w-5 h-5 text-pink-500 fill-pink-500" />
                  Saved Master Bookmarks
                </h3>
                <span className="bg-pink-100 text-pink-600 text-xs font-black px-2.5 py-0.5 rounded-full">
                  {favorites.length} SAVED
                </span>
              </div>

              {favorites.length === 0 ? (
                <div className="text-center text-sm text-slate-400 py-10 italic">
                  Bookmarked items from your generated outputs appear here.
                </div>
              ) : (
                <div className="space-y-3 max-h-[280px] overflow-y-auto pr-2 custom-scrollbar">
                  {favorites.map((fav) => (
                    <div 
                      key={fav.id}
                      className="p-3 bg-slate-50 border border-slate-200/60 rounded-xl relative"
                    >
                      <div className="flex justify-between items-start gap-2 mb-1">
                        <span className="text-[9px] font-black text-pink-500 uppercase tracking-widest leading-none">
                          {fav.tone} ({fav.language})
                        </span>
                        <button 
                          onClick={() => toggleFavorite(fav)}
                          className="text-slate-400 hover:text-red-500 transition-colors"
                          title="Unfavorite"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                      <p className="text-xs font-black text-slate-800 leading-snug mb-1.5">
                        "{fav.hookText}"
                      </p>
                      
                      <div className="bg-white/80 p-2 rounded border border-slate-100 text-[10px] text-slate-500 leading-relaxed">
                        <span className="font-bold text-pink-600">Visual Guide: </span> {fav.visualCue}
                      </div>

                      <div className="flex justify-between items-center mt-2 pt-1 border-t border-slate-100/50">
                        <span className="text-[8px] text-slate-400 font-bold truncate max-w-[130px]" title={fav.productDescription}>
                          Product: {fav.productDescription}
                        </span>
                        <button 
                          onClick={() => navigator.clipboard.writeText(fav.hookText)}
                          className="text-[9px] bg-white border border-slate-200 hover:bg-slate-100 px-2 py-0.5 rounded font-extrabold text-slate-600 cursor-pointer flex items-center gap-1"
                        >
                          <Copy className="w-2.5 h-2.5" /> Copy Text
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 text-[11px] text-slate-400 font-semibold flex justify-between">
              <span>Data persisted to local device storage.</span>
            </div>
          </div>

        </div>

        {/* AGENCY DEEP SERVICES SECTION */}
        <section id="services" className="bg-white border border-slate-200 rounded-[32px] p-6 md:p-12 mb-16 shadow-sm scroll-mt-24">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <span className="text-[10px] font-black text-pink-500 uppercase tracking-widest bg-pink-50 px-3 py-1 rounded-full border border-pink-100/40">
              Media Buy Ecosystem
            </span>
            <h2 className="text-3xl md:text-5xl font-black mt-4 mb-4 tracking-tight text-slate-900 leading-none">
              Strategic Growth Execution
            </h2>
            <p className="text-slate-500 text-md md:text-lg leading-relaxed font-semibold">
              We replace guesswork with formulaic performance marketing. Every ad campaign undergoes custom conversion validation and hook iteration natively.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            
            {/* Service Block #1 */}
            <div className="p-6 border border-slate-100 rounded-2xl bg-slate-50/50 hover:bg-white hover:shadow-lg transition-all">
              <div className="w-10 h-10 bg-pink-100 text-pink-600 rounded-xl flex items-center justify-center font-bold mb-4">
                01
              </div>
              <h4 className="font-extrabold text-lg text-slate-900 mb-2">
                UGC Blueprint Orchestration
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                We write, direct, and cast viral UGC content specifically calibrated to match high-retention performance hook metrics. You get fully raw edits optimized for continuous ad testing.
              </p>
            </div>

            {/* Service Block #2 */}
            <div className="p-6 border border-slate-100 rounded-2xl bg-slate-50/50 hover:bg-white hover:shadow-lg transition-all">
              <div className="w-10 h-10 bg-pink-100 text-pink-600 rounded-xl flex items-center justify-center font-bold mb-4">
                02
              </div>
              <h4 className="font-extrabold text-lg text-slate-900 mb-2">
                Meta Ad Funnels
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                Complete configuration of target exclusions, catalog triggers, Advantage+ workflows, and customized landing page sequences engineered strictly to minimize cost-per-acquisition.
              </p>
            </div>

            {/* Service Block #3 */}
            <div className="p-6 border border-slate-100 rounded-2xl bg-slate-50/50 hover:bg-white hover:shadow-lg transition-all md:col-span-2 lg:col-span-1">
              <div className="w-10 h-10 bg-pink-100 text-pink-600 rounded-xl flex items-center justify-center font-bold mb-4">
                03
              </div>
              <h4 className="font-extrabold text-lg text-slate-900 mb-2">
                Affiliate Partner Links
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                Integrations with premium platform links. We align directly on revenue structures and scale with official platform tools to drive mutual high-volume client conversion loops.
              </p>
            </div>

          </div>

          {/* Call-to-action bar dentro del bento */}
          <div className="mt-10 border-t border-slate-100 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-xs font-extrabold text-slate-400 uppercase tracking-widest text-center md:text-left">
              WANT TO DISCOVER NEW AD TARGETING SECRETS?
            </p>
            <a 
              href="#contact"
              className="bg-black hover:bg-slate-800 text-white font-bold text-xs px-6 py-3 rounded-full flex items-center gap-2 transform hover:-translate-y-0.5 transition-all w-full md:w-auto justify-center"
            >
              SCHEDULE A DEMO RUN
              <ArrowRight className="w-3.5 h-3.5 text-pink-500" />
            </a>
          </div>
        </section>

        {/* AGENCY ACCORDION FAQ SECTION */}
        <section id="faq" className="bg-white border border-slate-200 rounded-[32px] p-6 md:p-12 mb-16 shadow-sm scroll-mt-24">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <span className="text-[10px] font-black text-pink-500 uppercase tracking-widest bg-pink-50 px-2.5 py-1 rounded-full">
              Faq Accordion
            </span>
            <h2 className="text-2xl md:text-4xl font-black mt-3 mb-2 tracking-tight">
              Frequently Asked Questions
            </h2>
            <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">
              Answers from GetStock56 Elite Media Planners
            </p>
          </div>

          <div className="max-w-3xl mx-auto space-y-4">
            {faqItems.map((faq, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div 
                  key={index}
                  className={`border border-slate-100 rounded-2xl transition-all duration-300 ${
                    isOpen ? "shadow-sm border-pink-100 bg-pink-50/10" : "bg-[#f8fafc]/40 hover:bg-[#f8fafc]"
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                    className="w-full text-left px-6 py-5 flex justify-between items-center gap-4 font-extrabold text-slate-800 focus:outline-none cursor-pointer"
                  >
                    <span className="text-[14px] md:text-md tracking-tight leading-snug flex items-center gap-2">
                      <HelpCircle className="w-4 h-4 text-pink-500 shrink-0" />
                      {faq.q}
                    </span>
                    <ChevronDown className={`w-4 h-4 text-slate-400 shrink-0 transform transition-transform duration-300 ${
                      isOpen ? "rotate-180 text-pink-500" : ""
                    }`} />
                  </button>
                  
                  <div className={`faq-answer ${isOpen ? "max-h-[500px] opacity-100 border-t border-slate-100/50" : ""}`}>
                    <div className="px-6 py-5 text-slate-500 text-sm leading-relaxed font-semibold">
                      {faq.a}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* CONTACT AGENCY SECTION */}
        <section id="contact" className="bg-white border-2 border-slate-200/90 rounded-[32px] p-6 md:p-12 mb-16 shadow-sm scroll-mt-24 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-pink-500/5 rounded-bl-full pointer-events-none"></div>
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Branding side */}
            <div className="lg:col-span-5 space-y-4 text-left">
              <div className="w-12 h-12 bg-pink-100 text-pink-600 rounded-2xl flex items-center justify-center font-black">
                G56
              </div>
              <h2 className="text-3xl md:text-5xl font-black text-slate-900 tracking-tight leading-none">
                Start Scaling<br/>With Us Now.
              </h2>
              <p className="text-sm text-slate-500 font-semibold leading-relaxed">
                Unlock high-retention performance creatives, expert media buys, and strategic growth loops. Drop us details about your company and traffic challenges below.
              </p>
              
              <div className="space-y-3 pt-4">
                <div className="flex items-center gap-3 text-xs text-slate-600 font-bold">
                  <div className="w-7 h-7 bg-slate-100 rounded-lg flex items-center justify-center">
                    <Globe className="w-3.5 h-3.5 text-pink-500" />
                  </div>
                  <span>Universal English & Taglish Multi-channel Coverage</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-slate-600 font-bold">
                  <div className="w-7 h-7 bg-slate-100 rounded-lg flex items-center justify-center">
                    <Sparkles className="w-3.5 h-3.5 text-[#0668E1]" />
                  </div>
                  <span>Proven Ad ROI Metrics Orchestration</span>
                </div>
              </div>
            </div>

            {/* Interactive Leads Form details */}
            <div className="lg:col-span-7 bg-slate-50/50 border border-slate-100 rounded-2xl p-6 md:p-8">
              
              {contactSuccess ? (
                <div className="text-center py-8 space-y-4">
                  <div className="w-14 h-14 bg-green-50 text-green-500 border border-green-200 rounded-full flex items-center justify-center mx-auto shadow-sm">
                    <Check className="w-8 h-8 stroke-[3]" />
                  </div>
                  <h4 className="text-xl font-extrabold text-slate-900">Message Transmitted!</h4>
                  <p className="text-xs text-slate-500 leading-relaxed font-semibold max-w-sm mx-auto">
                    Thank you. A senior media manager from the GetStock56 team will evaluate your brand website structure and reach back within 24 operational hours.
                  </p>
                  <button 
                    type="button" 
                    onClick={() => setContactSuccess(false)}
                    className="text-xs font-bold text-pink-500 hover:text-pink-700 underline cursor-pointer"
                  >
                    Submit another operational request
                  </button>
                </div>
              ) : (
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label htmlFor="c-name" className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                        Full Name *
                      </label>
                      <input 
                        id="c-name"
                        type="text" 
                        required
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                        placeholder="e.g. Juan De Cruz"
                        className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 focus:ring-pink-500/20"
                      />
                    </div>
                    <div className="space-y-1">
                      <label htmlFor="c-email" className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                        Work Email *
                      </label>
                      <input 
                        id="c-email"
                        type="email" 
                        required
                        value={contactEmail}
                        onChange={(e) => setContactEmail(e.target.value)}
                        placeholder="e.g. juan@brand.com"
                        className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 focus:ring-pink-500/20"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label htmlFor="c-website" className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                      Brand Website URL
                    </label>
                    <input 
                      id="c-website"
                      type="url" 
                      value={contactWebsite}
                      onChange={(e) => setContactWebsite(e.target.value)}
                      placeholder="e.g. https://brand.com"
                      className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 focus:ring-pink-500/20"
                    />
                  </div>

                  <div className="space-y-1">
                    <label htmlFor="c-message" className="text-[10px] font-black text-slate-400 uppercase tracking-widest block">
                      Describe your Growth Goals / Products *
                    </label>
                    <textarea 
                      id="c-message"
                      rows={3} 
                      required
                      value={contactMessage}
                      onChange={(e) => setContactMessage(e.target.value)}
                      placeholder="Share your current daily ad spend, platforms tested, and what products you seek to scale..."
                      className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs text-slate-800 font-semibold focus:outline-none focus:ring-2 focus:ring-pink-500/20 resize-none leading-relaxed"
                    />
                  </div>

                  <button 
                    type="submit"
                    disabled={contactSubmitting}
                    className="w-full bg-black text-white hover:bg-slate-800 p-3.5 rounded-xl font-black text-xs tracking-wider flex items-center justify-center gap-2 transform active:scale-98 transition-colors cursor-pointer"
                  >
                    {contactSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 text-pink-500 animate-spin" />
                        SUBMITTING LOG...
                      </>
                    ) : (
                      <>
                        SUBMIT DISCOVERY AUDIT
                        <Send className="w-3.5 h-3.5 text-pink-500" />
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>

          </div>
        </section>

        {/* BOTTOM PARTNERS SWIPER (BENTO FOOTER BAR) */}
        <div className="bg-white border border-slate-200 rounded-[32px] px-6 md:px-10 py-6 flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm mb-16">
          <span className="text-[10px] font-black text-slate-300 uppercase tracking-[0.3em] text-center">
            ACCESSIBLE OFFICIAL AD PARTNERS
          </span>
          
          <div className="flex flex-wrap justify-center items-center gap-8 text-slate-800">
            
            {/* Meta Partner */}
            <a 
              href="https://www.facebook.com/business" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex items-center gap-1.5 opacity-40 hover:opacity-100 hover:text-[#0668E1] transition-all cursor-pointer"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.469h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.469h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
              <span className="font-black tracking-tight text-sm">Meta</span>
            </a>

            {/* TikTok partner */}
            <a 
              href="https://getstartedtiktok.partnerlinks.io/l05gptx6mnto" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex items-center gap-1.5 opacity-40 hover:opacity-100 hover:text-rose-500 transition-all cursor-pointer"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M12.525.023C11.962.051 11.412.185 10.9.417c-1.127.513-1.94 1.522-2.317 2.766L8.513 3.4l-.105.51a5.753 5.753 0 0 1-.09 1.043l-.008.21h-.148c-.623.004-1.25.132-1.841.385-1.037.443-1.833 1.251-2.222 2.256-.144.373-.255.855-.303 1.26a8.55 8.55 0 0 0-.012 1.488c.038.563.141 1.128.31 1.666a4.912 4.912 0 0 0 1.954 2.67c.755.513 1.642.794 2.585.83l.298.012l.1.51c.365 1.82 1.393 3.398 2.87 4.39 1.41.947 3.195 1.3 4.92 1.012a6.9 6.9 0 0 0 2.835-1.144c1.173-.83 2.05-2.016 2.486-3.37l.142-.44.408-.073a5.52 5.52 0 0 0 1.954-.83c.883-.563 1.543-1.42 1.875-2.45.19-.59.27-1.18.25-1.804a5.16 5.16 0 0 0-1.803-4.22c-.67-.55-1.474-.88-2.35-.985l-.27-.03-.042-.23c-.234-1.284-.962-2.4-2.03-3.136a6.83 6.83 0 0 0-4.664-1.026z"/>
              </svg>
              <span className="font-black tracking-tight text-sm">TikTok</span>
            </a>

            {/* YouTube Part */}
            <a 
              href="https://www.youtube.com/ads/" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex items-center gap-1.5 opacity-40 hover:opacity-100 hover:text-red-600 transition-all cursor-pointer"
            >
              <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
              </svg>
              <span className="font-black tracking-tight text-sm">YouTube</span>
            </a>

            <div className="h-4 w-[1.5px] bg-slate-200 hidden sm:block"></div>
            <div className="text-slate-400 font-extrabold text-[11px] uppercase tracking-wider">
              +12 Networks Covered
            </div>

          </div>
        </div>

      </main>

      {/* FOOTER AGENCY INFO */}
      <footer className="bg-white border-t border-slate-200 py-12 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-2">
            <span className="text-sm font-black text-slate-300 uppercase tracking-widest">
              © {new Date().getFullYear()} GetStock56 Universal. All rights reserved.
            </span>
          </div>

          <div className="flex gap-4 text-xs font-bold text-slate-400">
            <a href="#home" className="hover:text-pink-500 transition-all">Back to apex top</a>
            <span>·</span>
            <a href="#services" className="hover:text-pink-500 transition-all">Growth strategies</a>
            <span>·</span>
            <a href="https://getstartedtiktok.partnerlinks.io/l05gptx6mnto" target="_blank" className="hover:text-pink-500 transition-all inline-flex items-center gap-1">
              Platform Link <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </footer>

      {/* SYSTEM PERSISTENT MOBILE BOTTOM NAVIGATION TAB BAR */}
      <nav id="mobile-nav" className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-50 flex justify-around items-center px-1 py-2.5 shadow-[0_-4px_10px_rgba(0,0,0,0.03)] safe-area-pb">
        <a 
          href="#home" 
          className={`flex flex-col items-center gap-0.5 transition-colors w-14 ${
            activeSection === "home" ? "text-pink-600 font-extrabold" : "text-slate-500 hover:text-pink-500"
          }`}
        >
          <Home className="w-4 h-4" />
          <span className="text-[9px] font-black uppercase tracking-wider">Home</span>
        </a>
        <a 
          href="#services" 
          className={`flex flex-col items-center gap-0.5 transition-colors w-14 ${
            activeSection === "services" ? "text-pink-600 font-extrabold" : "text-slate-500 hover:text-pink-500"
          }`}
        >
          <Briefcase className="w-4 h-4" />
          <span className="text-[9px] font-black uppercase tracking-wider">Services</span>
        </a>
        <a 
          href="#ai-tool" 
          className={`flex flex-col items-center gap-0.5 transition-colors w-14 ${
            activeSection === "ai-tool" ? "text-pink-600 font-extrabold" : "text-slate-500 hover:text-pink-500"
          }`}
        >
          <Sparkles className="w-4 h-4" />
          <span className="text-[9px] font-black uppercase tracking-wider">AI Tool</span>
        </a>
        
        {/* Real Mobile System Settings configuration */}
        <button 
          onClick={() => setSettingsOpen(true)}
          className={`flex flex-col items-center gap-0.5 transition-colors w-14 cursor-pointer focus:outline-none ${
            settingsOpen ? "text-pink-600 font-extrabold" : "text-slate-500 hover:text-pink-500"
          }`}
        >
          <Settings className="w-4 h-4" />
          <span className="text-[9px] font-black uppercase tracking-wider">Settings</span>
        </button>

        <a 
          href="#contact" 
          className={`flex flex-col items-center gap-0.5 transition-colors w-14 ${
            activeSection === "contact" ? "text-pink-600 font-extrabold" : "text-slate-500 hover:text-pink-500"
          }`}
        >
          <Mail className="w-4 h-4" />
          <span className="text-[9px] font-black uppercase tracking-wider">Contact</span>
        </a>
      </nav>

    </div>
  );
}
