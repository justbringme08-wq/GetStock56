export interface Hook {
  hookText: string;
  visualCue: string;
  reason: string;
}

export interface GeneratedHookResponse {
  hooks: Hook[];
}

export interface FavoriteHook extends Hook {
  id: string;
  timestamp: string;
  productDescription: string;
  language: string;
  tone: string;
}

export interface RecentSearch {
  id: string;
  productDescription: string;
  language: string;
  tone: string;
  timestamp: string;
}

export type ToneType = 
  | "Direct & Aggressive"
  | "Informative & Educational"
  | "Humorous & Relatable"
  | "Curiosity & Mystery"
  | "Urgent & FOMO";

export type LanguageType = "English" | "Tagalog";
