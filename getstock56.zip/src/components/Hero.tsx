import { ArrowRight } from "lucide-react";

export default function Hero() {
  return (
    <section id="top" className="relative max-w-6xl mx-auto px-6 py-20 md:py-36 text-center flex flex-col justify-center w-full overflow-hidden">
      {/* Decorative gradient glow background */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] sm:w-[500px] md:w-[700px] h-[350px] sm:h-[500px] md:h-[700px] bg-pink-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

      <div className="animate-fade-in-up">
        {/* Soft tag */}
        <span className="inline-flex items-center gap-1.5 px-4 py-1.5 bg-pink-50 text-pink-600 rounded-full text-xs font-semibold uppercase tracking-wider mb-8 border border-pink-100/50">
          🚀 Universal Performance Marketing Agency
        </span>

        {/* Display headline */}
        <h1 className="text-4xl sm:text-6xl md:text-8xl font-extrabold mb-8 leading-[1.1] tracking-tight text-gray-900">
          Scale Across<br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-500 to-rose-400">
            All Platforms
          </span>
        </h1>
        
        {/* Subhead narrative */}
        <p className="text-lg sm:text-xl md:text-2xl text-gray-500 mb-12 max-w-2xl mx-auto leading-relaxed font-semibold">
          Data-driven, high-converting ad strategies for TikTok, Meta, and beyond.
        </p>

        {/* Action Links */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center max-w-lg mx-auto sm:max-w-none">
          <a 
            href="https://getstartedtiktok.partnerlinks.io/l05gptx6mnto" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="group bg-black text-white text-lg px-8 sm:px-10 py-4 rounded-full font-extrabold shadow-xl shadow-black/10 hover:bg-gray-900 hover:shadow-black/20 hover:-translate-y-0.5 transition-all flex items-center gap-3 w-full sm:w-auto justify-center cursor-pointer"
          >
            Start Scaling 
            <ArrowRight className="w-5 h-5 stroke-[2.5] group-hover:translate-x-1 transition-transform text-pink-500" />
          </a>
          <a 
            href="#services" 
            className="bg-white text-gray-900 border border-gray-200 text-lg px-8 sm:px-10 py-4 rounded-full font-bold hover:border-gray-300 hover:bg-gray-50 transition-all flex items-center gap-3 w-full sm:w-auto justify-center cursor-pointer"
          >
            View Services
          </a>
        </div>
      </div>
    </section>
  );
}
