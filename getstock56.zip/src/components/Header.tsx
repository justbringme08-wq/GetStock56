import { useState, useEffect } from "react";
import { Sparkles, Briefcase, Mail, ExternalLink } from "lucide-react";

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header 
      id="top-header"
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? "bg-white/90 backdrop-blur-md shadow-md border-b border-gray-100 py-3" 
          : "bg-white/80 backdrop-blur-sm shadow-sm py-4"
      }`}
    >
      <nav className="max-w-6xl mx-auto px-6 flex justify-between items-center">
        {/* Brand Logo */}
        <a href="#top" className="text-2xl font-extrabold text-black tracking-tight hover:opacity-95 transition-opacity">
          GET<span className="text-pink-500">STOCK56</span>
        </a>
        
        {/* Navigation Links (Desktop only) */}
        <div className="space-x-8 font-semibold hidden md:flex items-center">
          <a href="#services" className="hover:text-pink-500 transition-colors text-gray-600 flex items-center gap-1.5">
            <Briefcase className="w-4 h-4" />
            Services
          </a>
          <a href="#ai-tool" className="hover:text-pink-500 transition-colors text-gray-600 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-pink-500" />
            AI Hook Tools
          </a>
          <a href="#faq" className="hover:text-pink-500 transition-colors text-gray-600">
            FAQ
          </a>
          <a 
            href="#contact" 
            className="bg-black text-white px-6 py-2.5 rounded-full hover:bg-gray-800 transition-all font-semibold shadow-sm hover:shadow-md transform hover:-translate-y-0.5"
          >
            Get Started
          </a>
        </div>
      </nav>
    </header>
  );
}
