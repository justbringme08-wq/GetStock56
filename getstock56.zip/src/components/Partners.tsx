import { AtSign } from "lucide-react";

export default function Partners() {
  const partnersList = [
    {
      name: "Facebook",
      url: "https://www.facebook.com/business",
      hoverClass: "hover:text-[#0668E1]",
      icon: (
        <svg className="w-6 h-6 shrink-0" viewBox="0 0 24 24" fill="currentColor">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.469h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.469h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>
      )
    },
    {
      name: "YouTube",
      url: "https://www.youtube.com/ads/",
      hoverClass: "hover:text-[#FF0000]",
      icon: (
        <svg className="w-6 h-6 shrink-0" viewBox="0 0 24 24" fill="currentColor">
          <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
        </svg>
      )
    },
    {
      name: "Twitter",
      url: "https://ads.twitter.com/",
      hoverClass: "hover:text-black",
      icon: (
        <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="currentColor">
          <path d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z"/>
        </svg>
      )
    },
    {
      name: "Pinterest",
      url: "https://business.pinterest.com/",
      hoverClass: "hover:text-[#E60023]",
      icon: (
        <svg className="w-6 h-6 shrink-0" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.162-.105-.949-.199-2.403.041-3.439.219-.937 1.406-5.957 1.406-5.957s-.359-.72-.359-1.781c0-1.663.967-2.911 2.168-2.911 1.024 0 1.518.769 1.518 1.688 0 1.029-.653 2.567-.992 3.992-.285 1.193.6 2.165 1.775 2.165 2.128 0 3.768-2.245 3.768-5.487 0-2.861-2.063-4.869-5.008-4.869-3.41 0-5.409 2.562-5.409 5.199 0 1.033.394 2.143.889 2.741.099.12.112.225.085.345-.09.375-.293 1.199-.334 1.363-.053.225-.172.271-.401.165-1.495-.69-2.433-2.878-2.433-4.646 0-3.776 2.748-7.252 7.951-7.252 4.168 0 7.41 2.967 7.41 6.923 0 4.135-2.607 7.462-6.233 7.462-1.214 0-2.354-.629-2.758-1.379l-.749 2.848c-.269 1.045-1.004 2.352-1.498 3.146 1.123.345 2.306.535 3.55.535 6.607 0 11.985-5.365 11.985-11.987C23.97 5.367 18.592 0 12.017 0z"/>
        </svg>
      )
    },
    {
      name: "Threads",
      url: "https://www.threads.net/",
      hoverClass: "hover:text-black",
      icon: (
        <AtSign className="w-6 h-6 shrink-0 stroke-[2.5]" />
      )
    },
    {
      name: "LinkedIn",
      url: "https://business.linkedin.com/marketing-solutions",
      hoverClass: "hover:text-[#0077b5]",
      icon: (
        <svg className="w-6 h-6 shrink-0" viewBox="0 0 24 24" fill="currentColor">
          <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/>
        </svg>
      )
    }
  ];

  return (
    <section className="py-12 bg-white border-y border-gray-100">
      <div className="max-w-6xl mx-auto px-6">
        <p className="text-center text-xs font-bold text-gray-400 tracking-widest uppercase mb-8">
          Trusted By Brands across Main Networks
        </p>
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12 opacity-65 grayscale hover:grayscale-0 transition-all duration-300">
          {partnersList.map((p) => (
            <a 
              key={p.name}
              href={p.url} 
              target="_blank" 
              rel="noopener noreferrer" 
              className={`flex items-center gap-2 transition-colors duration-200 cursor-pointer ${p.hoverClass}`}
            >
              {p.icon}
              <span className="text-lg font-extrabold tracking-tighter text-gray-800 hover:text-inherit">
                {p.name}
              </span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
