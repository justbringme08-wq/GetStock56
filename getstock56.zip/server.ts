import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize server-side Gemini client securely
// Using User-Agent telemetry headers as per AI Studio guidelines
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Ad Hook Generation Endpoint
app.post("/api/generate-hooks", async (req, res) => {
  try {
    const { productDescription, language, tone, platform, ugcStyle, prefixModifier } = req.body;

    if (!productDescription || !productDescription.trim()) {
      return res.status(400).json({ error: "Product description is required." });
    }

    const selectedLanguage = language || "English";
    const selectedTone = tone || "Direct & Aggressive";
    const selectedPlatform = platform || "TikTok";
    const selectedUgcStyle = ugcStyle || "Casual Creator Voice";
    const usePrefixModifier = prefixModifier === true;

    const systemInstruction = `
      You are an elite vertical growth advertiser, conversion copywriter, and UGC video creator at GetStock56 Universal.
      Your task is to write 5 highly engaging, pattern-interrupting video ad hooks of maximum 12 words.
      These hooks are aimed primarily at ${selectedPlatform}.
      The creators will use a "${selectedUgcStyle}" style for production.
      
      LANGUAGE INSTRUCTIONS:
      - If the user selects "Tagalog", write the hooks in ultra-natural, conversational casual Taglish/Tagalog. Use modern conversational Philippine lingo (e.g. "Gusto mo ba...", "Alam mo ba na...", "Grabeng...", or real phrases Filipinos say. Keep it relatable and dynamic, never stiff, formal, or literal translation/textbook Tagalog).
      - If the user selects "English", write in catchy, conversational, high-converting English. Often starting with "If you...", "Stop...", "How I got...", "Unpopular opinion...".
      
      TONE ATTRIBUTES DIRECTIVE:
      - "Direct & Aggressive": Callout pain points, bold hooks, immediate solution.
      - "Informative & Educational": Actionable hacks, surprise statistics, "How to..."
      - "Humorous & Relatable": Fun, expressive, mock common awkward situations.
      - "Curiosity & Mystery": Secretive, cliffhangers, "The one trick Google doesn't want you to know".
      - "Urgent & FOMO": Fear of missing out, "Stop doing X", "Only for people who want Y".
      
      ${usePrefixModifier ? `
      PATTERN INTERRUPT PREFIXES MANDATE:
      - You MUST start each of the 5 hooks with a short, highly arresting warning, reaction, or attention prefix suitable for ${selectedPlatform}. E.g.: "⚠️ GRABE!", "⚠️ STOP SCROLLING!", "Wait...", "⚠️ UNPOPULAR OPINION:", "⚠️ PRO TIP:", "POV:" etc.
      ` : ''}

      Provide on-screen visual motion guide matching the "${selectedUgcStyle}" visual vibe for the first 3 seconds.
      Provide a brief 1-sentence analytical reason for why the hook converts this platform's specific user demographic.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: `Product: ${productDescription}\nLanguage: ${selectedLanguage}\nTone: ${selectedTone}\nPlatform: ${selectedPlatform}\nUGC Style: ${selectedUgcStyle}`,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["hooks"],
          properties: {
            hooks: {
              type: Type.ARRAY,
              description: "List of exactly 5 hooks",
              items: {
                type: Type.OBJECT,
                required: ["hookText", "visualCue", "reason"],
                properties: {
                  hookText: {
                    type: Type.STRING,
                    description: "The video hook subtitle lines (Conversational, under 12 words)."
                  },
                  visualCue: {
                    type: Type.STRING,
                    description: "UGC production cue or active behavior to show in the first 3 seconds matching style."
                  },
                  reason: {
                    type: Type.STRING,
                    description: "Marketing psychology behind this specific hook (1 sentence)."
                  }
                }
              }
            }
          }
        }
      }
    });

    const hookText = response.text;
    if (!hookText) {
      throw new Error("Empty response from AI engine.");
    }

    const outputJson = JSON.parse(hookText);
    return res.json(outputJson);
  } catch (err: any) {
    console.error("AI Hook Generator API Error:", err);
    return res.status(500).json({ error: err.message || "An error occurred during generation." });
  }
});

async function startServer() {
  // Configure Vite middleware in development or direct static serving in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
